package api_rest.java_cloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaCloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaCloudApplication.class, args);
	}

}
