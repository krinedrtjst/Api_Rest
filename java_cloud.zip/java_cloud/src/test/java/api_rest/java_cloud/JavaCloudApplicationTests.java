package api_rest.java_cloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaCloudApplicationTests {

	@Test
	void contextLoads() {
	}

}
